$('.special.card .image').dimmer({
          on: 'hover'
});

$(document).ready(function() {
    $('.tooltip').tooltipster({
        theme: "tooltipster-shadow",
        contentCloning: true
    });
});